package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.BorderStroke
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import com.example.data.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val GrayText = Color(0xFF94A3B8)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResultScreen(
    viewModel: CleanerViewModel,
    onNavigateHome: () -> Unit,
    onNavigateToPremium: () -> Unit,
    onNavigateToCleaner: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val scanStep by viewModel.scanStep.collectAsState()
    val junkList by viewModel.junkList.collectAsState()
    val largeFiles by viewModel.largeFiles.collectAsState()
    val duplicateGroups by viewModel.duplicateGroups.collectAsState()
    val installedApps by viewModel.installedApps.collectAsState()
    val storageCategories by viewModel.storageCategories.collectAsState()
    val isPremium by viewModel.isPremium.collectAsState()
    val isInternetAvailable by viewModel.isInternetAvailable.collectAsState()
    val hasCleaned by viewModel.hasCleanedThisSession.collectAsState()
    val showAdEvent by viewModel.showAdEvent.collectAsState()

    var selectedTabIndex by remember { mutableStateOf(0) }
    val tabTitles = listOf("Junk", "Large", "Duplicates", "Apps", "Analyzer")

    val scope = rememberCoroutineScope()
    var showInterstitialMock by remember { mutableStateOf(false) }
    var interstitialCountdown by remember { mutableStateOf(3) }

    // Interstitial Ad Logic Trigger
    LaunchedEffect(showAdEvent) {
        if (showAdEvent && !isPremium && isInternetAvailable) {
            showInterstitialMock = true
            interstitialCountdown = 3
            while (interstitialCountdown > 0) {
                delay(1000)
                interstitialCountdown--
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Scan Reports",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                },
                navigationIcon = {
                    IconButton(onClick = {
                        viewModel.resetState()
                        onNavigateHome()
                    }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    // Premium action removed to satisfy user request
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        },
        bottomBar = {
            // Mock AdMob Banner Ad at the bottom (Fulfilling Monetization rules)
            if (!isPremium && isInternetAvailable) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                        .testTag("admob_banner_card"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "Ad",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "AdMob Banner: AI Guardian Security",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Enhance security and diagnostics. Tap to upgrade.",
                                    fontSize = 9.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        IconButton(
                            onClick = onNavigateToPremium,
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Star,
                                contentDescription = "Upgrade icon",
                                tint = MaterialTheme.colorScheme.tertiary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        },
        containerColor = Color.Transparent,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Secondary Scrollable Tab row
                ScrollableTabRow(
                    selectedTabIndex = selectedTabIndex,
                    containerColor = Color.Transparent,
                    edgePadding = 12.dp,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                ) {
                    tabTitles.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTabIndex == index,
                            onClick = { selectedTabIndex = index },
                            text = {
                                Text(
                                    text = title,
                                    fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal,
                                    color = if (selectedTabIndex == index) MaterialTheme.colorScheme.primary else GrayText
                                )
                            }
                        )
                    }
                }

                // Main screen view selector based on selected tab index
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    when (selectedTabIndex) {
                        0 -> JunkCleanerTab(viewModel = viewModel, hasCleaned = hasCleaned, onNavigateToCleaner = onNavigateToCleaner)
                        1 -> LargeFilesTab(viewModel = viewModel, onNavigateToCleaner = onNavigateToCleaner)
                        2 -> DuplicateFinderTab(viewModel = viewModel, onNavigateToCleaner = onNavigateToCleaner)
                        3 -> AppManagerTab(viewModel = viewModel)
                        4 -> StorageAnalyzerTab(viewModel = viewModel, categories = storageCategories)
                    }
                }
            }

            // 6. ADMOB MOCK INTERSTITIAL OVERLAY
            if (showInterstitialMock) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.9f))
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Card(
                        modifier = Modifier.fillMaxWidth().wrapContentHeight(),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .background(Color.Gray.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(text = "Sponsored", fontSize = 10.sp, color = GrayText)
                                }

                                if (interstitialCountdown > 0) {
                                    Text(
                                        text = "Close in $interstitialCountdown...",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                } else {
                                    IconButton(
                                        onClick = {
                                            showInterstitialMock = false
                                            viewModel.dismissAd()
                                        },
                                        modifier = Modifier.size(28.dp).testTag("close_ad_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Close,
                                            contentDescription = "Close Ad",
                                            tint = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }

                            Icon(
                                imageVector = Icons.Rounded.RocketLaunch,
                                contentDescription = "Ad brand icon",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(60.dp)
                            )

                            Text(
                                text = "AdMob Interstitial Ad",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )

                            Text(
                                text = "Keep your device 100% optimized. Unlock Premium details to automatically schedule cleaner processes without interruption.",
                                style = MaterialTheme.typography.bodyMedium,
                                textAlign = TextAlign.Center,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Button(
                                onClick = {
                                    showInterstitialMock = false
                                    viewModel.dismissAd()
                                    onNavigateToPremium()
                                },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Upgrade & Remove Ads")
                            }
                        }
                    }
                }
            }
        }
    }
}

// 1. JUNK CLEANER SCREEN TAB
@Composable
fun JunkCleanerTab(
    viewModel: CleanerViewModel,
    hasCleaned: Boolean,
    onNavigateToCleaner: (String) -> Unit
) {
    val items by viewModel.junkList.collectAsState()
    val totalCheckedSize = items.filter { it.checked }.sumOf { it.size }

    if (hasCleaned || items.sumOf { it.size } == 0L) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Rounded.CheckCircle,
                contentDescription = "System fully optimized logo",
                tint = Color(0xFF34D399),
                modifier = Modifier.size(100.dp)
            )
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "System Fully Optimized",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "All temporary caches, residual trash files and advertisement junk have been cleared securely.",
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center,
                color = GrayText
            )
        }
    } else {
        Column(modifier = Modifier.fillMaxSize()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.05f))
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Junk Files Found",
                            style = MaterialTheme.typography.bodyMedium,
                            color = GrayText
                        )
                        Text(
                            text = viewModel.formatSize(totalCheckedSize),
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Button(
                        onClick = { onNavigateToCleaner("junk") },
                        enabled = totalCheckedSize > 0,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("safe_clean_button")
                    ) {
                        Text(
                            text = "Safe Clean",
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(items) { item ->
                    if (item.size > 0L) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.toggleJunkItem(item.id) },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Checkbox(
                                        checked = item.checked,
                                        onCheckedChange = { viewModel.toggleJunkItem(item.id) },
                                        colors = CheckboxDefaults.colors(checkedColor = MaterialTheme.colorScheme.primary)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            text = item.name,
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                        Text(
                                            text = item.description,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = GrayText,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                                Text(
                                    text = viewModel.formatSize(item.size),
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// 2. LARGE FILES TAB
@Composable
fun LargeFilesTab(
    viewModel: CleanerViewModel,
    onNavigateToCleaner: (String) -> Unit
) {
    val items by viewModel.largeFiles.collectAsState()
    val totalCheckedSize = items.filter { it.checked }.sumOf { it.size }

    if (items.isEmpty()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Rounded.FolderOff,
                contentDescription = "No large files",
                tint = GrayText.copy(alpha = 0.5f),
                modifier = Modifier.size(80.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "No Large Files Detected",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = GrayText
            )
        }
    } else {
        Column(modifier = Modifier.fillMaxSize()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.05f))
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Selected files size:",
                            style = MaterialTheme.typography.bodySmall,
                            color = GrayText
                        )
                        Text(
                            text = viewModel.formatSize(totalCheckedSize),
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black),
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                    Button(
                        onClick = { onNavigateToCleaner("large") },
                        enabled = totalCheckedSize > 0,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Delete Selected")
                    }
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(items) { item ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.toggleLargeFileItem(item.id) },
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Checkbox(
                                    checked = item.checked,
                                    onCheckedChange = { viewModel.toggleLargeFileItem(item.id) }
                                )
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(
                                            if (item.type == "Video") Color(0xFF2979FF).copy(alpha = 0.15f)
                                            else Color(0xFFFF9100).copy(alpha = 0.15f),
                                            CircleShape
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (item.type == "Video") Icons.Rounded.Movie else Icons.Rounded.Description,
                                        contentDescription = "File Type",
                                        tint = if (item.type == "Video") Color(0xFF2979FF) else Color(0xFFFF9100),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = item.name,
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.bodyMedium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = item.path,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = GrayText,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            Text(
                                text = viewModel.formatSize(item.size),
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DuplicatePhotoPreview(name: String, modifier: Modifier = Modifier) {
    val colors = listOf(
        Color(0xFF2979FF), Color(0xFF00E5FF), Color(0xFFD500F9),
        Color(0xFFFF9100), Color(0xFFFF1744), Color(0xFF00E676),
        Color(0xFFFFEA00), Color(0xFF3D5AFE)
    )
    val hash = name.hashCode()
    val primaryColor = colors[Math.abs(hash) % colors.size]
    val secondaryColor = colors[Math.abs(hash * 3) % colors.size]

    Box(
        modifier = modifier
            .background(
                androidx.compose.ui.graphics.Brush.linearGradient(
                    colors = listOf(primaryColor.copy(alpha = 0.3f), secondaryColor.copy(alpha = 0.8f))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = if (Math.abs(hash) % 2 == 0) Icons.Rounded.Landscape else Icons.Rounded.Camera,
            contentDescription = "Photo Preview Placeholder",
            tint = Color.White.copy(alpha = 0.85f),
            modifier = Modifier.size(24.dp)
        )
    }
}

@Composable
fun AppIconView(packageName: String, modifier: Modifier = Modifier) {
    val context = androidx.compose.ui.platform.LocalContext.current
    androidx.compose.ui.viewinterop.AndroidView(
        factory = { ctx ->
            android.widget.ImageView(ctx).apply {
                scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
            }
        },
        modifier = modifier,
        update = { imageView ->
            try {
                val pm = context.packageManager
                val icon = pm.getApplicationIcon(packageName)
                imageView.setImageDrawable(icon)
            } catch (e: Exception) {
                imageView.setImageResource(android.R.drawable.sym_def_app_icon)
            }
        }
    )
}

// 3. DUPLICATE FINDER TAB
@Composable
fun DuplicateFinderTab(
    viewModel: CleanerViewModel,
    onNavigateToCleaner: (String) -> Unit
) {
    val groups by viewModel.duplicateGroups.collectAsState()
    val totalCheckedSize = groups.flatMap { it.photos }.filter { it.checked }.sumOf { it.size }

    if (groups.isEmpty()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Rounded.CheckCircleOutline,
                contentDescription = "Clean photo duplicates",
                tint = Color(0xFF34D399),
                modifier = Modifier.size(80.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "No Photo Duplicates Left",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = GrayText
            )
        }
    } else {
        Column(modifier = Modifier.fillMaxSize()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.05f))
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Duplicates checked:",
                            style = MaterialTheme.typography.bodySmall,
                            color = GrayText
                        )
                        Text(
                            text = viewModel.formatSize(totalCheckedSize),
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Button(
                        onClick = { onNavigateToCleaner("duplicates") },
                        enabled = totalCheckedSize > 0,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Delete Duplicates")
                    }
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(groups) { group ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            // Header of Group
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Rounded.Filter,
                                        contentDescription = "Group",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = group.previewName,
                                        fontWeight = FontWeight.ExtraBold,
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                }
                                Text(
                                    text = viewModel.formatSize(group.totalSize),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = GrayText
                                )
                            }

                            Divider(modifier = Modifier.padding(vertical = 10.dp))

                            // List of photo copies
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                group.photos.forEach { photo ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { viewModel.toggleDuplicatePhotoItem(group.id, photo.id) }
                                            .padding(vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Checkbox(
                                                checked = photo.checked,
                                                onCheckedChange = { viewModel.toggleDuplicatePhotoItem(group.id, photo.id) }
                                            )
                                            DuplicatePhotoPreview(
                                                name = photo.name,
                                                modifier = Modifier
                                                    .size(44.dp)
                                                    .clip(RoundedCornerShape(8.dp))
                                            )
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Column {
                                                Text(
                                                    text = photo.name,
                                                    style = MaterialTheme.typography.bodySmall,
                                                    fontWeight = FontWeight.Medium,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                if (photo.checked) {
                                                    Text(
                                                        text = "Suggested Candidate for cleaning",
                                                        fontSize = 10.sp,
                                                        color = MaterialTheme.colorScheme.primary,
                                                        fontWeight = FontWeight.SemiBold
                                                    )
                                                }
                                            }
                                        }
                                        Text(
                                            text = viewModel.formatSize(photo.size),
                                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 4. APP MANAGER TAB
@Composable
fun AppManagerTab(viewModel: CleanerViewModel) {
    val items by viewModel.installedApps.collectAsState()

    if (items.isEmpty()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Rounded.AppBlocking,
                contentDescription = "No apps found",
                tint = GrayText.copy(alpha = 0.5f),
                modifier = Modifier.size(80.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "All Apps Screen Scanned",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = GrayText
            )
        }
    } else {
        Column(modifier = Modifier.fillMaxSize()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.05f))
                    .padding(14.dp)
            ) {
                Text(
                    text = "Suggested cleanup apps below are unused for more than 30 days.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(items) { item ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                AppIconView(
                                    packageName = item.packageName,
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = item.label,
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                        if (item.isUnusedSuggestion) {
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Box(
                                                modifier = Modifier
                                                    .background(Color(0xFFFF9100).copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                            ) {
                                                Text(
                                                    text = "Unused",
                                                    fontSize = 9.sp,
                                                    color = Color(0xFFFF9100),
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }
                                    Text(
                                        text = "v${item.versionName} • Last used: ${item.lastUsedDays} days ago • ${viewModel.formatSize(item.size)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = GrayText
                                    )
                                }
                            }

                            val context = androidx.compose.ui.platform.LocalContext.current
                            IconButton(
                                onClick = {
                                    try {
                                        val intent = android.content.Intent(android.content.Intent.ACTION_DELETE).apply {
                                            data = android.net.Uri.parse("package:${item.packageName}")
                                        }
                                        context.startActivity(intent)
                                    } catch (e: Exception) {
                                        viewModel.uninstallApp(item.packageName)
                                    }
                                },
                                colors = IconButtonDefaults.iconButtonColors(
                                    contentColor = MaterialTheme.colorScheme.error
                                )
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.DeleteOutline,
                                    contentDescription = "Uninstall app",
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// 5. STORAGE ANALYZER TAB
@Composable
fun StorageDonutChart(
    categories: List<StorageCategory>,
    modifier: Modifier = Modifier
) {
    var animationPlayed by remember { mutableStateOf(false) }
    val animateProgress by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (animationPlayed) 1f else 0f,
        animationSpec = androidx.compose.animation.core.tween(
            durationMillis = 1000,
            easing = androidx.compose.animation.core.LinearOutSlowInEasing
        ),
        label = "DonutChartProgress"
    )

    LaunchedEffect(key1 = true) {
        animationPlayed = true
    }

    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.foundation.Canvas(
            modifier = Modifier
                .size(180.dp)
                .padding(8.dp)
        ) {
            var startAngle = -90f
            categories.forEach { category ->
                val sweepAngle = (category.percentage / 100f) * 360f * animateProgress
                drawArc(
                    color = Color(category.color),
                    startAngle = startAngle,
                    sweepAngle = sweepAngle,
                    useCenter = false,
                    style = androidx.compose.ui.graphics.drawscope.Stroke(
                        width = 18.dp.toPx(),
                        cap = androidx.compose.ui.graphics.StrokeCap.Round
                    )
                )
                startAngle += (category.percentage / 100f) * 360f
            }
        }

        // Center labels
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Used Space",
                style = MaterialTheme.typography.bodySmall,
                color = GrayText
            )
            val totalUsedPercentage = categories.sumOf { it.percentage.toDouble() }
            Text(
                text = String.format("%.1f%%", totalUsedPercentage),
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.ExtraBold),
                color = MaterialTheme.colorScheme.onBackground
            )
        }
    }
}

@Composable
fun StorageAnalyzerTab(
    viewModel: CleanerViewModel,
    categories: List<StorageCategory>
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                StorageDonutChart(categories = categories)
            }
        }

        item {
            Text(
                text = "SECTOR STORAGE ALLOCATION",
                style = MaterialTheme.typography.labelLarge.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                ),
                color = GrayText
            )
        }

        items(categories) { category ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .background(Color(category.color).copy(alpha = 0.15f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = when (category.iconName) {
                                        "image" -> Icons.Rounded.Image
                                        "movie" -> Icons.Rounded.Movie
                                        "audiotrack" -> Icons.Rounded.MusicNote
                                        "description" -> Icons.Rounded.Description
                                        "android" -> Icons.Rounded.Android
                                        "download" -> Icons.Rounded.Download
                                        else -> Icons.Rounded.Folder
                                    },
                                    contentDescription = category.name,
                                    tint = Color(category.color),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = category.name,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = viewModel.formatSize(category.size),
                                fontWeight = FontWeight.ExtraBold,
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text(
                                text = String.format("%.1f%%", category.percentage),
                                style = MaterialTheme.typography.bodySmall,
                                color = GrayText
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    LinearProgressIndicator(
                        progress = { category.percentage / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(CircleShape),
                        color = Color(category.color),
                        trackColor = Color(category.color).copy(alpha = 0.1f)
                    )
                }
            }
        }
    }
}
