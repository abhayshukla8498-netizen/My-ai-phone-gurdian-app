package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CleanerViewModel

private val GrayText = Color(0xFF94A3B8)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: CleanerViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val darkModeState by viewModel.darkModeState.collectAsState()
    val isPremium by viewModel.isPremium.collectAsState()
    val backgroundType by viewModel.backgroundType.collectAsState()
    val customVideoUri by viewModel.customVideoUri.collectAsState()
    val customVideoUrl by viewModel.customVideoUrl.collectAsState()
    val appStoreMode by viewModel.appStoreMode.collectAsState()
    val samsungOptimizationActive by viewModel.samsungOptimizationActive.collectAsState()

    val context = LocalContext.current
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var showTermsDialog by remember { mutableStateOf(false) }
    var showRatingDialog by remember { mutableStateOf(false) }
    var ratingValue by remember { mutableStateOf(5) }
    var ratingComment by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Settings",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("settings_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Back to home"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent
                )
            )
        },
        containerColor = Color.Transparent,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            // 1. THEME MODE SELECTOR (DARK MODE SECTION)
            SettingsGroup(title = "Appearance & Theme") {
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    // Choose App Theme Color Scheme
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Choose App Theme:",
                            style = MaterialTheme.typography.bodyMedium,
                            color = GrayText,
                            modifier = Modifier.padding(horizontal = 4.dp)
                        )
                        
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            ThemeOptionButton(
                                label = "Dark",
                                icon = Icons.Rounded.DarkMode,
                                isSelected = darkModeState == "dark",
                                onClick = { viewModel.setDarkMode("dark") },
                                modifier = Modifier.weight(1f).testTag("theme_dark_button")
                            )
                            ThemeOptionButton(
                                label = "Light",
                                icon = Icons.Rounded.LightMode,
                                isSelected = darkModeState == "light",
                                onClick = { viewModel.setDarkMode("light") },
                                modifier = Modifier.weight(1f).testTag("theme_light_button")
                            )
                            ThemeOptionButton(
                                label = "Auto",
                                icon = Icons.Rounded.SettingsSuggest,
                                isSelected = darkModeState == "system",
                                onClick = { viewModel.setDarkMode("system") },
                                modifier = Modifier.weight(1f).testTag("theme_system_button")
                            )
                        }
                    }

                    HorizontalDivider(
                        modifier = Modifier.padding(vertical = 4.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.08f)
                    )

                    // Choose Background Backdrop style
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Choose Background Style:",
                            style = MaterialTheme.typography.bodyMedium,
                            color = GrayText,
                            modifier = Modifier.padding(horizontal = 4.dp)
                        )
                        
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            ThemeOptionButton(
                                label = "Classic",
                                icon = Icons.Rounded.Wallpaper,
                                isSelected = backgroundType == "classic",
                                onClick = { viewModel.setBackgroundType("classic") },
                                modifier = Modifier.weight(1f)
                            )
                            ThemeOptionButton(
                                label = "Gradient",
                                icon = Icons.Rounded.Gradient,
                                isSelected = backgroundType == "gradient",
                                onClick = { viewModel.setBackgroundType("gradient") },
                                modifier = Modifier.weight(1f)
                            )
                            ThemeOptionButton(
                                label = "Video",
                                icon = Icons.Rounded.Movie,
                                isSelected = backgroundType == "video",
                                onClick = { viewModel.setBackgroundType("video") },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    // Video customization controls details panel
                    if (backgroundType == "video") {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                            ),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "LIVE VIDEO BACKGROUND CONTROLS",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.sp
                                    ),
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.height(12.dp))

                                // Video Presets list
                                Text(
                                    text = "Choose a gorgeous looping preset:",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = GrayText
                                )
                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    val presets = listOf(
                                        "Laser Lights" to "https://assets.mixkit.co/videos/preview/mixkit-abstract-laser-lights-background-31742-large.mp4",
                                        "Digital Net" to "https://assets.mixkit.co/videos/preview/mixkit-digital-network-connection-background-loop-33027-large.mp4",
                                        "Tech Lines" to "https://assets.mixkit.co/videos/preview/mixkit-abstract-digital-connection-lines-background-32585-large.mp4"
                                    )

                                    presets.forEach { (name, url) ->
                                        val isSelected = customVideoUrl == url && customVideoUri.isNullOrEmpty()
                                        Button(
                                            onClick = {
                                                viewModel.setCustomVideoUri(null)
                                                viewModel.setCustomVideoUrl(url)
                                            },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                                                contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                                            ),
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                            modifier = Modifier.weight(1f).height(36.dp)
                                        ) {
                                            Text(name, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(16.dp))

                                // Pick Video launcher
                                val videoPickerLauncher = rememberLauncherForActivityResult(
                                    contract = ActivityResultContracts.GetContent()
                                ) { uri: Uri? ->
                                    if (uri != null) {
                                        viewModel.setCustomVideoUri(uri.toString())
                                        viewModel.setCustomVideoUrl("")
                                    }
                                }

                                Button(
                                    onClick = { videoPickerLauncher.launch("video/*") },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = MaterialTheme.colorScheme.secondary
                                    ),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.VideoLibrary,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (!customVideoUri.isNullOrEmpty()) "Change Gallery Video" else "Choose Video from Gallery",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }

                                if (!customVideoUri.isNullOrEmpty()) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(10.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Rounded.CheckCircle,
                                                    contentDescription = "Active",
                                                    tint = Color(0xFF00E676),
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = "Custom Gallery Video Selected",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontWeight = FontWeight.Bold,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                            TextButton(
                                                onClick = { viewModel.setCustomVideoUri(null) },
                                                colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
                                                contentPadding = PaddingValues(0.dp)
                                            ) {
                                                Text("Reset", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(16.dp))

                                // Or Input direct URL textfield
                                Text(
                                    text = "Or enter custom direct MP4 stream URL:",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = GrayText
                                )
                                Spacer(modifier = Modifier.height(6.dp))

                                var urlText by remember(customVideoUrl) { mutableStateOf(customVideoUrl) }
                                OutlinedTextField(
                                    value = urlText,
                                    onValueChange = {
                                        urlText = it
                                        viewModel.setCustomVideoUri(null)
                                        viewModel.setCustomVideoUrl(it)
                                    },
                                    placeholder = { Text("https://example.com/video.mp4", style = MaterialTheme.typography.bodyMedium) },
                                    singleLine = true,
                                    shape = RoundedCornerShape(12.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                                        unfocusedBorderColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.2f)
                                    ),
                                    textStyle = MaterialTheme.typography.bodyMedium,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }
            }

            // 2. CLEANING HISTORY SECTION
            val historyLogs by viewModel.cleaningHistory.collectAsState()
            SettingsGroup(title = "Cleaning History") {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Rounded.History,
                                    contentDescription = "History Log",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = "On-Device Logs",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                            if (historyLogs.isNotEmpty()) {
                                TextButton(
                                    onClick = { viewModel.clearAllCleaningHistory() },
                                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                                ) {
                                    Text("Clear All", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        if (historyLogs.isEmpty()) {
                            Text(
                                text = "No local cleaning history available yet. Tap Scan Now on the home screen to start optimizing storage safely.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = GrayText,
                                modifier = Modifier.padding(vertical = 4.dp)
                            )
                        } else {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                historyLogs.take(5).forEach { log ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(
                                                text = log.cleanType,
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Bold
                                            )
                                            val dateStr = remember(log.timestamp) {
                                                val sdf = java.text.SimpleDateFormat("MMM dd, yyyy • HH:mm", java.util.Locale.getDefault())
                                                sdf.format(java.util.Date(log.timestamp))
                                            }
                                            Text(
                                                text = dateStr,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = GrayText
                                            )
                                        }

                                        Column(horizontalAlignment = Alignment.End) {
                                            Text(
                                                text = "+${viewModel.formatSize(log.reclaimedBytes)}",
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                            Text(
                                                text = "${log.filesCleanedCount} files",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = GrayText
                                            )
                                        }
                                    }
                                    if (log != historyLogs.take(5).last()) {
                                        Divider(
                                            modifier = Modifier.padding(vertical = 6.dp),
                                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.08f)
                                        )
                                    }
                                }
                                if (historyLogs.size > 5) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Showing 5 of ${historyLogs.size} logs",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = GrayText,
                                        modifier = Modifier.align(Alignment.CenterHorizontally)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 3. PRIVACY & LOCAL SECURITY STANDARD SECTION
            SettingsGroup(title = "Security & Privacy") {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
                    modifier = Modifier.fillMaxWidth().testTag("privacy_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.VerifiedUser,
                                contentDescription = "Privacy Shield",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "On-Device Processing",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }

                        Text(
                            text = "AI Phone Guardian values your total privacy. All data scanned is evaluated completely on-device. No images, personal details, file structures, or battery metrics are ever transmitted or saved outside your telephone.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Divider(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.1f))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Lock,
                                contentDescription = "Secure Lock",
                                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f),
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "Zero Cloud-Upload Mandate",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }

            // 3. STORE & GALAXY COMPLIANCE PREFERENCES
            SettingsGroup(title = "Store & Galaxy Compatibility") {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = "Active App Store Target Mode:",
                                style = MaterialTheme.typography.bodyMedium,
                                color = GrayText,
                                modifier = Modifier.padding(horizontal = 4.dp)
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                ThemeOptionButton(
                                    label = "Google Play",
                                    icon = Icons.Rounded.Android,
                                    isSelected = appStoreMode == "google_play",
                                    onClick = { viewModel.setAppStoreMode("google_play") },
                                    modifier = Modifier.weight(1f)
                                )
                                ThemeOptionButton(
                                    label = "Galaxy Store",
                                    icon = Icons.Rounded.PhoneAndroid,
                                    isSelected = appStoreMode == "samsung_galaxy",
                                    onClick = { viewModel.setAppStoreMode("samsung_galaxy") },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        Divider(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.08f))

                        // Switch row for Samsung Custom Memory reclamation
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Memory,
                                        contentDescription = "Memory Optimization",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "Galaxy RAM Optimizer",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "Knox & One UI memory reclamation standard",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = GrayText
                                    )
                                }
                            }
                            Switch(
                                checked = samsungOptimizationActive,
                                onCheckedChange = { viewModel.setSamsungOptimizationActive(it) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                                    checkedTrackColor = MaterialTheme.colorScheme.primary
                                )
                            )
                        }

                        Divider(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.08f))

                        // Dynamic status info card showing Galaxy Store review compliance state
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.05f))
                                .padding(12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Rounded.Verified,
                                    contentDescription = "Verified",
                                    tint = Color(0xFF00E676),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "GALAXY COMPLIANCE SECURE",
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            letterSpacing = 0.5.sp
                                        ),
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = "100% offline, privacy policy certified, support configured. Ready for Samsung App Store submission.",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = GrayText
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 4. PLAY STORE COMPLIANCE & SUPPORT SECTION
            SettingsGroup(title = "Support & Legal") {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                ) {
                    Column {
                        ClickableSettingsRow(
                            label = "Contact Customer Support",
                            description = "Email: abhayshukla8498@gmail.com",
                            icon = Icons.Rounded.Email,
                            isFirst = true,
                            onClick = {
                                val emailIntent = Intent(Intent.ACTION_SENDTO).apply {
                                    data = Uri.parse("mailto:")
                                    putExtra(Intent.EXTRA_EMAIL, arrayOf("abhayshukla8498@gmail.com"))
                                    putExtra(Intent.EXTRA_SUBJECT, "AI Phone Guardian - Customer Support Request")
                                    putExtra(Intent.EXTRA_TEXT, "Hello Customer Support Team,\n\n[Write your query/issue details here]\n\nDevice: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}\nAndroid OS: ${android.os.Build.VERSION.RELEASE}")
                                }
                                try {
                                    context.startActivity(Intent.createChooser(emailIntent, "Send Email Support Request"))
                                } catch (e: Exception) {
                                    Toast.makeText(context, "Email client not found. Support email is abhayshukla8498@gmail.com", Toast.LENGTH_LONG).show()
                                }
                            }
                        )
                        Divider(
                            modifier = Modifier.padding(horizontal = 16.dp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.08f)
                        )
                        ClickableSettingsRow(
                            label = "Privacy Policy",
                            description = "Review strict on-device data safety & storage rules",
                            icon = Icons.Rounded.Policy,
                            onClick = { showPrivacyDialog = true }
                        )
                        Divider(
                            modifier = Modifier.padding(horizontal = 16.dp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.08f)
                        )
                        ClickableSettingsRow(
                            label = "Terms of Service",
                            description = "Learn user guidelines & security liabilities",
                            icon = Icons.Rounded.Gavel,
                            onClick = { showTermsDialog = true }
                        )
                        Divider(
                            modifier = Modifier.padding(horizontal = 16.dp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.08f)
                        )
                        ClickableSettingsRow(
                            label = "Rate AI Phone Guardian",
                            description = if (appStoreMode == "samsung_galaxy") "Rate us on Samsung Galaxy Store" else "Leave 5-star feedback on Google Play Store",
                            icon = Icons.Rounded.Star,
                            onClick = { showRatingDialog = true }
                        )
                        Divider(
                            modifier = Modifier.padding(horizontal = 16.dp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.08f)
                        )
                        ClickableSettingsRow(
                            label = "Share App",
                            description = "Share high-speed offline cleaner with friends",
                            icon = Icons.Rounded.Share,
                            isLast = true,
                            onClick = {
                                val packageName = context.packageName
                                val storeLink = if (appStoreMode == "samsung_galaxy") {
                                    "https://galaxystore.samsung.com/detail/$packageName"
                                } else {
                                    "https://play.google.com/store/apps/details?id=$packageName"
                                }
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_SUBJECT, "Optimize your Phone with AI Phone Guardian")
                                    putExtra(Intent.EXTRA_TEXT, "Check out AI Phone Guardian! It safely cleans storage junk, checks real-time battery status, and tracks system diagnostics 100% on-device. Download it here: $storeLink")
                                }
                                try {
                                    context.startActivity(Intent.createChooser(shareIntent, "Share App Link"))
                                } catch (e: Exception) {
                                    Toast.makeText(context, "Unable to share app. Please try again.", Toast.LENGTH_SHORT).show()
                                }
                            }
                        )
                    }
                }
            }

            // 4. APPLICATION INFORMATION SECTION
            SettingsGroup(title = "App Information") {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                ) {
                    Column {
                        InfoRow(
                            label = "App Name",
                            value = "AI Phone Guardian",
                            icon = Icons.Rounded.Info,
                            isFirst = true
                        )
                        Divider(
                            modifier = Modifier.padding(horizontal = 16.dp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.08f)
                        )
                        InfoRow(
                            label = "Version",
                            value = "2.0.1 (Stable)",
                            icon = Icons.Rounded.PhonelinkSetup
                        )
                        Divider(
                            modifier = Modifier.padding(horizontal = 16.dp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.08f)
                        )
                        InfoRow(
                            label = "Local Diagnostic Engine",
                            value = "v4.2-Secure",
                            icon = Icons.Rounded.Memory
                        )
                        Divider(
                            modifier = Modifier.padding(horizontal = 16.dp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.08f)
                        )
                        InfoRow(
                            label = "License Status",
                            value = "Fully Activated & Secure",
                            icon = Icons.Rounded.Verified,
                            iconColor = MaterialTheme.colorScheme.primary,
                            isLast = true
                        )
                    }
                }
            }

            // 4. DESIGN METRIC AT BOTTOM
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Rounded.Shield,
                    contentDescription = "Shield Logo",
                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.25f),
                    modifier = Modifier.size(36.dp)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "AI Phone Guardian • Guardian Core Security",
                    style = MaterialTheme.typography.labelSmall,
                    color = GrayText.copy(alpha = 0.5f),
                    letterSpacing = 1.sp
                )
            }
        }
    }

    if (showPrivacyDialog) {
        PrivacyPolicyDialog(onDismiss = { showPrivacyDialog = false })
    }

    if (showTermsDialog) {
        TermsOfServiceDialog(onDismiss = { showTermsDialog = false })
    }

    if (showRatingDialog) {
        RatingFeedbackDialog(
            rating = ratingValue,
            onRatingChange = { ratingValue = it },
            comment = ratingComment,
            onCommentChange = { ratingComment = it },
            onDismiss = { showRatingDialog = false },
            onSubmit = {
                showRatingDialog = false
                Toast.makeText(context, "Thank you so much for your 5-star review and suggestions!", Toast.LENGTH_LONG).show()
                if (ratingValue >= 4) {
                    val packageName = context.packageName
                    val storeUri = if (appStoreMode == "samsung_galaxy") {
                        Uri.parse("samsungapps://ProductDetail/$packageName")
                    } else {
                        Uri.parse("market://details?id=$packageName")
                    }
                    val intent = Intent(Intent.ACTION_VIEW, storeUri)
                    try {
                        context.startActivity(intent)
                    } catch (e: Exception) {
                        // Fallback to web link if native store app is not installed
                        val webUri = if (appStoreMode == "samsung_galaxy") {
                            Uri.parse("https://galaxystore.samsung.com/detail/$packageName")
                        } else {
                            Uri.parse("https://play.google.com/store/apps/details?id=$packageName")
                        }
                        try {
                            context.startActivity(Intent(Intent.ACTION_VIEW, webUri))
                        } catch (ex: Exception) {
                            // Suppress
                        }
                    }
                }
                ratingComment = ""
            }
        )
    }
}

@Composable
fun SettingsGroup(
    title: String,
    content: @Composable () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = title.uppercase(),
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp
            ),
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(horizontal = 4.dp)
        )
        content()
    }
}

@Composable
fun ThemeOptionButton(
    label: String,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface
    val contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
    val borderStroke = if (isSelected) null else BorderStroke(1.dp, MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.12f))

    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = containerColor,
        contentColor = contentColor,
        border = borderStroke,
        modifier = modifier
            .height(52.dp)
            .minimumInteractiveComponentSize()
    ) {
        Row(
            modifier = Modifier.fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
fun InfoRow(
    label: String,
    value: String,
    icon: ImageVector,
    iconColor: Color = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f),
    isFirst: Boolean = false,
    isLast: Boolean = false
) {
    val shape = when {
        isFirst && isLast -> RoundedCornerShape(16.dp)
        isFirst -> RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
        isLast -> RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp)
        else -> RoundedCornerShape(0.dp)
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(MaterialTheme.colorScheme.surface)
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = iconColor,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = label,
                    fontWeight = FontWeight.Medium,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            Text(
                text = value,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.bodyMedium,
                color = GrayText,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun ClickableSettingsRow(
    label: String,
    description: String,
    icon: ImageVector,
    iconColor: Color = MaterialTheme.colorScheme.primary.copy(alpha = 0.8f),
    isFirst: Boolean = false,
    isLast: Boolean = false,
    onClick: () -> Unit
) {
    val shape = when {
        isFirst && isLast -> RoundedCornerShape(16.dp)
        isFirst -> RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
        isLast -> RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp)
        else -> RoundedCornerShape(0.dp)
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(MaterialTheme.colorScheme.surface)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = iconColor,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = label,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = description,
                        style = MaterialTheme.typography.labelSmall,
                        color = GrayText
                    )
                }
            }
            Icon(
                imageVector = Icons.Rounded.ChevronRight,
                contentDescription = "Navigate",
                tint = GrayText.copy(alpha = 0.6f),
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
fun PrivacyPolicyDialog(
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Rounded.Policy,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Privacy Policy",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 320.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Effective Date: June 2026",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                Text(
                    text = "1. Introduction\n" +
                            "Welcome to AI Phone Guardian. We respect your digital privacy. This document outlines our transparent policy regarding user data scanning, storage, and device performance diagnostics.",
                    style = MaterialTheme.typography.bodyMedium
                )

                Text(
                    text = "2. On-Device Processing Commitment\n" +
                            "All storage scanning, RAM evaluations, duplicates sorting, and junk cache assessments are executed entirely on your local device. We have a strict ZERO cloud-upload mandate. No private images, media files, or application logs ever leave your device.",
                    style = MaterialTheme.typography.bodyMedium
                )

                Text(
                    text = "3. Requested Permissions & Usage\n" +
                            "• Storage Permission: Utilized exclusively to locate secure cache, duplicate pictures, and bulky redundant files for deletion.\n" +
                            "• Query All Packages: Needed solely to display installed application status so you can identify resource-heavy software on your phone.\n" +
                            "• Samsung Device Optimization: Fully compliant with Samsung One UI guidelines and Knox security specifications, ensuring no root or deep-system modifications are performed.",
                    style = MaterialTheme.typography.bodyMedium
                )

                Text(
                    text = "4. Battery & Hardware Telemetry\n" +
                            "We read battery charge rates, status, heat levels, and operating voltage dynamically via Android's local BatteryManager API. This data is displayed strictly in real-time in the UI and is never stored or collected.",
                    style = MaterialTheme.typography.bodyMedium
                )

                Text(
                    text = "5. Third-Party Integrations & Galaxy Store Policy\n" +
                            "We do not use tracking SDKs, commercial ad trackers, or background analysis servers. Your data is 100% yours. Fully compliant with both Google Play Developer policies and Samsung Galaxy Store policies.",
                    style = MaterialTheme.typography.bodyMedium
                )

                Text(
                    text = "6. Developer Contact\n" +
                            "If you have queries or request data details, contact our customer support team at: abhayshukla8498@gmail.com",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Dismiss", fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
fun TermsOfServiceDialog(
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Rounded.Gavel,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Terms of Service",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 320.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Effective Date: June 2026",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                Text(
                    text = "1. Agreement of Use\n" +
                            "By downloading and accessing AI Phone Guardian, you agree to comply with and be bound by these legal terms. If you do not agree, please do not use the application.",
                    style = MaterialTheme.typography.bodyMedium
                )

                Text(
                    text = "2. Services and Operations\n" +
                            "AI Phone Guardian provides client-side utility services, including cache clear assists, diagnostic listings, duplicate image detection support, and device health logs.",
                    style = MaterialTheme.typography.bodyMedium
                )

                Text(
                    text = "3. Absolute User Responsibility\n" +
                            "Any action of file deletion, junk cleaning, or photo pruning is executed strictly upon user confirmation. Users hold complete responsibility for backing up important media or files before initiating permanent deletions.",
                    style = MaterialTheme.typography.bodyMedium
                )

                Text(
                    text = "4. Disclaimers of Warranties\n" +
                            "This application is provided 'as is' without warranties of any kind. AI Phone Guardian is not liable for inadvertent system file adjustments or personal data loss originating from system cleanup executions.",
                    style = MaterialTheme.typography.bodyMedium
                )

                Text(
                    text = "5. Revisions of Terms\n" +
                            "We reserve the right to revise these terms to align with Play Store policies. Support contact is open at: abhayshukla8498@gmail.com",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("I Accept", fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
fun RatingFeedbackDialog(
    rating: Int,
    onRatingChange: (Int) -> Unit,
    comment: String,
    onCommentChange: (String) -> Unit,
    onDismiss: () -> Unit,
    onSubmit: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Icon(
                    imageVector = Icons.Rounded.ThumbUp,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(36.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Rate AI Phone Guardian",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "Your rating helps us improve security and diagnostics for millions of users worldwide!",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    for (i in 1..5) {
                        IconButton(onClick = { onRatingChange(i) }) {
                            Icon(
                                imageVector = if (i <= rating) Icons.Rounded.Star else Icons.Rounded.StarOutline,
                                contentDescription = "$i Stars",
                                tint = if (i <= rating) Color(0xFFFFB300) else GrayText.copy(alpha = 0.5f),
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = comment,
                    onValueChange = onCommentChange,
                    placeholder = { Text("Write custom suggestion or feedback...", style = MaterialTheme.typography.bodyMedium) },
                    singleLine = false,
                    maxLines = 3,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.2f)
                    ),
                    textStyle = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onSubmit,
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Submit", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", fontWeight = FontWeight.Bold)
            }
        }
    )
}
