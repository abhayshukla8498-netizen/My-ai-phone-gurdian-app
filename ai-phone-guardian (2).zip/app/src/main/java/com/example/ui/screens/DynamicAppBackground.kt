package com.example.ui.screens

import android.content.Context
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.net.Uri
import android.view.TextureView
import android.view.Surface
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.example.data.CleanerViewModel
import com.example.ui.theme.*

@Composable
fun DynamicAppBackground(
    viewModel: CleanerViewModel,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val backgroundType by viewModel.backgroundType.collectAsState()
    val customVideoUri by viewModel.customVideoUri.collectAsState()
    val customVideoUrl by viewModel.customVideoUrl.collectAsState()
    val darkModeState by viewModel.darkModeState.collectAsState()

    val isSystemDark = isSystemInDarkTheme()
    val isDarkTheme = when (darkModeState) {
        "dark" -> true
        "light" -> false
        else -> isSystemDark
    }

    // Determine classic colors
    val baseColor = if (isDarkTheme) DarkBackground else LightBackground

    // Animating the base background transition
    val animatedBgColor by animateColorAsState(
        targetValue = baseColor,
        animationSpec = tween(durationMillis = 500),
        label = "BgColorAnimation"
    )

    Box(modifier = modifier.fillMaxSize()) {
        // Base solid color layer
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(animatedBgColor)
        )

        // Gradient Background Layer
        if (backgroundType == "gradient") {
            val gradientBrush = if (isDarkTheme) {
                Brush.linearGradient(
                    colors = listOf(
                        Color(0xFF080B10), // Deep Space Black
                        Color(0xFF0F1A2C), // Cosmic Navy
                        Color(0xFF240A42)  // Nebula Violet
                    )
                )
            } else {
                Brush.linearGradient(
                    colors = listOf(
                        Color(0xFFEAF5FF), // Pale Aurora Blue
                        Color(0xFFF4F0FF), // Pale Orchid
                        Color(0xFFE8F8F4)  // Pale Emerald
                    )
                )
            }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(gradientBrush)
            )
        }

        // Looping Video Background Layer
        if (backgroundType == "video") {
            val videoSource = when {
                !customVideoUri.isNullOrEmpty() -> customVideoUri!!
                customVideoUrl.isNotEmpty() -> customVideoUrl
                else -> "https://assets.mixkit.co/videos/preview/mixkit-abstract-laser-lights-background-31742-large.mp4"
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .alpha(if (isDarkTheme) 0.28f else 0.15f) // Subtle overlay alpha to keep cards perfectly readable
            ) {
                VideoLoopView(videoSource = videoSource)
            }

            // Darken/Tint overlay to ensure Material 3 text contrast is flawless
            val tintColor = if (isDarkTheme) Color.Black.copy(alpha = 0.4f) else Color.White.copy(alpha = 0.3f)
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(tintColor)
            )
        }

        // Main app content layered beautifully on top
        content()
    }
}

@Composable
fun VideoLoopView(videoSource: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var mediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }

    LaunchedEffect(videoSource) {
        val mp = MediaPlayer().apply {
            isLooping = true
            // Play video silently as a gorgeous background aesthetic
            setVolume(0f, 0f)
        }
        var success = false
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            try {
                if (videoSource.startsWith("content://") || videoSource.startsWith("android.resource://")) {
                    mp.setDataSource(context, Uri.parse(videoSource))
                } else {
                    mp.setDataSource(videoSource)
                }
                success = true
            } catch (e: Exception) {
                e.printStackTrace()
                try {
                    mp.reset()
                    mp.setDataSource("https://assets.mixkit.co/videos/preview/mixkit-abstract-laser-lights-background-31742-large.mp4")
                    success = true
                } catch (ex: Exception) {
                    ex.printStackTrace()
                }
            }
        }
        if (success) {
            mediaPlayer = mp
        } else {
            try {
                mp.release()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    DisposableEffect(mediaPlayer) {
        onDispose {
            try {
                mediaPlayer?.stop()
            } catch (e: Exception) {
                e.printStackTrace()
            }
            try {
                mediaPlayer?.release()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // Manage standard lifecycle events to stop playback when app is paused
    DisposableEffect(lifecycleOwner, mediaPlayer) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE -> {
                    try {
                        mediaPlayer?.pause()
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
                Lifecycle.Event.ON_RESUME -> {
                    try {
                        mediaPlayer?.start()
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)

        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    // TextureView allows hardware acceleration and customized opacity blending
    if (mediaPlayer != null) {
        AndroidView(
            factory = { ctx ->
                TextureView(ctx).apply {
                    surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                        override fun onSurfaceTextureAvailable(surfaceTexture: SurfaceTexture, width: Int, height: Int) {
                            val surface = Surface(surfaceTexture)
                            try {
                                mediaPlayer?.setSurface(surface)
                                mediaPlayer?.setOnPreparedListener { mp ->
                                    try {
                                        mp.start()
                                    } catch (e: Exception) {
                                        e.printStackTrace()
                                    }
                                }
                                mediaPlayer?.prepareAsync()
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        }

                        override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {}

                        override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
                            try {
                                mediaPlayer?.setSurface(null)
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                            return true
                        }

                        override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
                    }
                }
            },
            modifier = modifier.fillMaxSize()
        )
    }
}
