package com.example.data

import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.StatFs
import androidx.compose.ui.graphics.Color
import java.io.File
import kotlin.random.Random

// Core Model Definitions
data class JunkItem(
    val id: String,
    val name: String,
    val size: Long,
    val category: String,
    val description: String,
    val checked: Boolean = true
)

data class LargeFile(
    val id: String,
    val name: String,
    val size: Long,
    val type: String,
    val path: String,
    val checked: Boolean = false
)

data class DuplicatePhoto(
    val id: String,
    val name: String,
    val size: Long,
    val checked: Boolean = false,
    val imageResId: Int = 0 // Optional, we can use built-in system paths or simulated icons
)

data class DuplicateGroup(
    val id: String,
    val previewName: String,
    val totalSize: Long,
    val photos: List<DuplicatePhoto>
)

data class AppInfo(
    val packageName: String,
    val label: String,
    val size: Long,
    val lastUsedDays: Int,
    val isUnusedSuggestion: Boolean,
    val checked: Boolean = false,
    val versionName: String = "1.0.0"
)

data class StorageCategory(
    val name: String,
    val size: Long,
    val color: Long, // Hex representation
    val percentage: Float,
    val iconName: String
)

enum class ScanStep {
    IDLE,
    SCANNING_JUNK,
    SCANNING_LARGE,
    SCANNING_DUPLICATES,
    SCANNING_APPS,
    SCANNING_ANALYSIS,
    COMPLETED
}

data class BatteryInfo(
    val level: Int,
    val isCharging: Boolean,
    val health: String,
    val temperature: Float, // in Celsius
    val voltage: Int, // in mV
    val technology: String
)

data class DeviceInfo(
    val model: String,
    val brand: String,
    val androidVersion: String,
    val sdkVersion: Int,
    val totalRam: Long, // in bytes
    val freeRam: Long,
    val totalStorage: Long,
    val freeStorage: Long,
    val cpuCores: Int
)

// Helper objects to generate realistic storage, battery and device metrics locally
object StorageManager {
    fun getStorageInfo(context: Context): DeviceInfo {
        val path = Environment.getDataDirectory()
        val stat = StatFs(path.path)
        val blockSize = stat.blockSizeLong
        val totalBlocks = stat.blockCountLong
        val availableBlocks = stat.availableBlocksLong

        val totalStorage = totalBlocks * blockSize
        val freeStorage = availableBlocks * blockSize

        // Fetch 100% real RAM metrics from ActivityManager MemoryInfo API
        var totalRam = 4L * 1024 * 1024 * 1024 // 4GB Fallback
        var freeRam = 1500L * 1024 * 1024 // 1.5GB Fallback
        try {
            val actManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? android.app.ActivityManager
            if (actManager != null) {
                val memInfo = android.app.ActivityManager.MemoryInfo()
                actManager.getMemoryInfo(memInfo)
                totalRam = memInfo.totalMem
                freeRam = memInfo.availMem
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return DeviceInfo(
            model = Build.MODEL,
            brand = Build.BRAND.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() },
            androidVersion = Build.VERSION.RELEASE,
            sdkVersion = Build.VERSION.SDK_INT,
            totalRam = totalRam,
            freeRam = freeRam,
            totalStorage = totalStorage,
            freeStorage = freeStorage,
            cpuCores = Runtime.getRuntime().availableProcessors()
        )
    }

    // Standard static data generator for offline-first operation, fully customizable
    fun generateJunkItems(context: Context): List<JunkItem> {
        val cacheDir = context.cacheDir
        val junkFiles = listOf(
            Triple("system_cache_bin.tmp", "System Cache Files", (120..180).random() * 1024 * 1024L),
            Triple("app_temp_data.temp", "App Temporary Files", (180..260).random() * 1024 * 1024L),
            Triple("residual_trash_v1.log", "Residual Trash Files", (60..110).random() * 1024 * 1024L),
            Triple("system_diagnostics.log", "System Log Files", (12..25).random() * 1024 * 1024L),
            Triple("ad_cache_meta_v3.temp", "Ad Trash Metadata", (30..55).random() * 1024 * 1024L)
        )

        return junkFiles.map { (fileName, label, size) ->
            val file = File(cacheDir, fileName)
            if (!file.exists()) {
                try {
                    val raf = java.io.RandomAccessFile(file, "rw")
                    raf.setLength(size)
                    raf.close()
                } catch (e: Exception) {
                    try {
                        file.writeText("Placeholder content for secure cleaning.")
                    } catch (ex: Exception) {}
                }
            }
            JunkItem(
                id = "junk_${fileName.hashCode()}",
                name = label,
                size = if (file.exists()) file.length() else size,
                category = "Cache",
                description = file.absolutePath,
                checked = true
            )
        }
    }

    fun generateLargeFiles(context: Context): List<LargeFile> {
        val filesDir = context.filesDir
        val largeFiles = listOf(
            Triple("movie_download_1080p.mp4", (100..150).random() * 1024 * 1024L, "Video"),
            Triple("com_game_assets.pak", (70..110).random() * 1024 * 1024L, "Document"),
            Triple("unboxing_video_4k.mp4", (40..65).random() * 1024 * 1024L, "Video"),
            Triple("annual_report_archive_2025.zip", (10..22).random() * 1024 * 1024L, "Zip"),
            Triple("presentation_pitch_final.pdf", (5..12).random() * 1024 * 1024L, "Document")
        )

        return largeFiles.map { (fileName, size, type) ->
            val file = File(filesDir, fileName)
            if (!file.exists()) {
                try {
                    val raf = java.io.RandomAccessFile(file, "rw")
                    raf.setLength(size)
                    raf.close()
                } catch (e: Exception) {
                    try {
                        file.writeText("Placeholder content.")
                    } catch (ex: Exception) {}
                }
            }
            LargeFile(
                id = "lf_${fileName.hashCode()}",
                name = fileName,
                size = if (file.exists()) file.length() else size,
                type = type,
                path = file.absolutePath,
                checked = false
            )
        }
    }

    fun generateDuplicatePhotos(context: Context): List<DuplicateGroup> {
        val cacheDir = context.cacheDir
        val groups = listOf(
            "Sunset Beach Scene" to listOf(
                "IMG_20260512_183421.jpg" to (3..5).random() * 1024 * 1024L,
                "IMG_20260512_183422.jpg" to (3..5).random() * 1024 * 1024L,
                "IMG_20260512_183422_burst.jpg" to (3..5).random() * 1024 * 1024L
            ),
            "Coffee Cup Latte Art" to listOf(
                "IMG_20260601_092104.jpg" to (2..4).random() * 1024 * 1024L,
                "IMG_20260601_092105_copy.jpg" to (2..4).random() * 1024 * 1024L
            ),
            "Group Selfie at Conference" to listOf(
                "IMG_20260615_141011.jpg" to (5..7).random() * 1024 * 1024L,
                "IMG_20260615_141012.jpg" to (5..7).random() * 1024 * 1024L,
                "IMG_20260615_141014.jpg" to (5..7).random() * 1024 * 1024L
            )
        )

        var groupId = 1
        return groups.map { (groupName, files) ->
            var totalSize = 0L
            val photos = files.mapIndexed { index, (fileName, size) ->
                val file = File(cacheDir, fileName)
                if (!file.exists()) {
                    try {
                        val raf = java.io.RandomAccessFile(file, "rw")
                        raf.setLength(size)
                        raf.close()
                    } catch (e: Exception) {
                        try {
                            file.writeText("Placeholder.")
                        } catch (ex: Exception) {}
                    }
                }
                val finalSize = if (file.exists()) file.length() else size
                totalSize += finalSize
                DuplicatePhoto(
                    id = "dp_${fileName.hashCode()}",
                    name = fileName,
                    size = finalSize,
                    checked = index > 0
                )
            }
            val group = DuplicateGroup(
                id = "dg_$groupId",
                previewName = groupName,
                totalSize = totalSize,
                photos = photos
            )
            groupId++
            group
        }
    }

    fun generateInstalledApps(): List<AppInfo> {
        return listOf(
            AppInfo("com.social.galaxy", "Galaxy Social", 640 * 1024 * 1024L, 1, false, versionName = "4.21.3"),
            AppInfo("com.racer.hypercar", "HyperCar Racer", 1850 * 1024 * 1024L, 45, true, versionName = "1.0.8"), // Unused suggest
            AppInfo("com.video.editor.pro", "Smart Video Pro", 380 * 1024 * 1024L, 12, false, versionName = "3.2.1"),
            AppInfo("com.shopping.prime", "PrimeStore", 420 * 1024 * 1024L, 3, false, versionName = "15.4.0"),
            AppInfo("com.puzzle.woodblocks", "Block Wood Puzzle", 240 * 1024 * 1024L, 95, true, versionName = "2.3.1"), // Unused suggest
            AppInfo("com.reader.epub", "Zen PDF Reader", 110 * 1024 * 1024L, 18, false, versionName = "1.12.0"),
            AppInfo("com.filter.camera.retro", "RetroCam Vintage", 310 * 1024 * 1024L, 35, true, versionName = "2.0.4") // Unused suggest
        )
    }

    fun generateStorageCategories(total: Long, free: Long): List<StorageCategory> {
        val used = total - free
        val images = (used * 0.22).toLong()
        val videos = (used * 0.28).toLong()
        val audio = (used * 0.10).toLong()
        val documents = (used * 0.12).toLong()
        val apks = (used * 0.08).toLong()
        val downloads = (used * 0.14).toLong()
        val other = used - (images + videos + audio + documents + apks + downloads)

        return listOf(
            StorageCategory("Images", images, 0xFF00E5FF, (images.toFloat() / total * 100), "image"),
            StorageCategory("Videos", videos, 0xFF2979FF, (videos.toFloat() / total * 100), "movie"),
            StorageCategory("Audio", audio, 0xFFD500F9, (audio.toFloat() / total * 100), "audiotrack"),
            StorageCategory("Documents", documents, 0xFFFF9100, (documents.toFloat() / total * 100), "description"),
            StorageCategory("APK Files", apks, 0xFF00E676, (apks.toFloat() / total * 100), "android"),
            StorageCategory("Downloads", downloads, 0xFFFFEA00, (downloads.toFloat() / total * 100), "download"),
            StorageCategory("Other", other, 0xFFFF1744, (other.toFloat() / total * 100), "folder")
        )
    }

    fun generateBatteryInfo(context: Context): BatteryInfo {
        var level = 82
        var isCharging = false
        var health = "Healthy"
        var temperature = 31.4f
        var voltage = 3980
        var technology = "Li-poly"

        try {
            val filter = android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED)
            val batteryStatus = context.registerReceiver(null, filter)
            if (batteryStatus != null) {
                val rawLevel = batteryStatus.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1)
                val rawScale = batteryStatus.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, -1)
                if (rawLevel != -1 && rawScale != -1) {
                    level = (rawLevel * 100 / rawScale.toFloat()).toInt()
                }

                val status = batteryStatus.getIntExtra(android.os.BatteryManager.EXTRA_STATUS, -1)
                isCharging = status == android.os.BatteryManager.BATTERY_STATUS_CHARGING || 
                             status == android.os.BatteryManager.BATTERY_STATUS_FULL

                val healthInt = batteryStatus.getIntExtra(android.os.BatteryManager.EXTRA_HEALTH, android.os.BatteryManager.BATTERY_HEALTH_UNKNOWN)
                health = when (healthInt) {
                    android.os.BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
                    android.os.BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"
                    android.os.BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheated"
                    android.os.BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over Voltage"
                    android.os.BatteryManager.BATTERY_HEALTH_COLD -> "Cold"
                    else -> "Healthy"
                }

                temperature = batteryStatus.getIntExtra(android.os.BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0f
                voltage = batteryStatus.getIntExtra(android.os.BatteryManager.EXTRA_VOLTAGE, 0)
                technology = batteryStatus.getStringExtra(android.os.BatteryManager.EXTRA_TECHNOLOGY) ?: "Li-ion"
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return BatteryInfo(
            level = level,
            isCharging = isCharging,
            health = health,
            temperature = temperature,
            voltage = voltage,
            technology = technology
        )
    }
}
