package com.example.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "cleaning_history")
data class CleaningHistory(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val timestamp: Long,
    val reclaimedBytes: Long,
    val filesCleanedCount: Int,
    val cleanType: String
)

@Dao
interface HistoryDao {
    @Query("SELECT * FROM cleaning_history ORDER BY timestamp DESC")
    fun getAllHistory(): Flow<List<CleaningHistory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(history: CleaningHistory)

    @Query("DELETE FROM cleaning_history")
    suspend fun clearAllHistory()
}

@Database(entities = [CleaningHistory::class], version = 1, exportSchema = false)
abstract class HistoryDatabase : RoomDatabase() {
    abstract fun historyDao(): HistoryDao

    companion object {
        @Volatile
        private var INSTANCE: HistoryDatabase? = null

        fun getDatabase(context: Context): HistoryDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    HistoryDatabase::class.java,
                    "history_database"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}

class HistoryRepository(private val historyDao: HistoryDao) {
    val allHistory: Flow<List<CleaningHistory>> = historyDao.getAllHistory()

    suspend fun insert(history: CleaningHistory) {
        historyDao.insertHistory(history)
    }

    suspend fun clearAll() {
        historyDao.clearAllHistory()
    }
}
