package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.data.CleanerViewModel
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      val viewModel: CleanerViewModel = viewModel()
      val darkModeState by viewModel.darkModeState.collectAsState()
      val isSystemDark = isSystemInDarkTheme()
      val isDarkTheme = when (darkModeState) {
        "dark" -> true
        "light" -> false
        else -> isSystemDark
      }

      MyApplicationTheme(darkTheme = isDarkTheme) {
        DynamicAppBackground(viewModel = viewModel) {
          Surface(
            modifier = Modifier.fillMaxSize(),
            color = androidx.compose.ui.graphics.Color.Transparent
          ) {
            val navController = rememberNavController()

          NavHost(
            navController = navController,
            startDestination = "splash"
          ) {
            composable("splash") {
              SplashScreen(
                onNavigateNext = {
                  navController.navigate("home") {
                    popUpTo("splash") { inclusive = true }
                  }
                }
              )
            }
            composable("home") {
              HomeScreen(
                viewModel = viewModel,
                onNavigateToScan = { navController.navigate("scan") },
                onNavigateToBattery = { navController.navigate("battery") },
                onNavigateToPremium = { navController.navigate("premium") },
                onNavigateToSettings = { navController.navigate("settings") },
                onNavigateToApkInstaller = { navController.navigate("apk_installer") }
              )
            }
            composable("scan") {
              ScanScreen(
                viewModel = viewModel,
                onFinishedScan = {
                  navController.navigate("result") {
                    popUpTo("home") { saveState = true }
                    launchSingleTop = true
                  }
                }
              )
            }
            composable("result") {
              ResultScreen(
                viewModel = viewModel,
                onNavigateHome = { navController.navigate("home") },
                onNavigateToPremium = { navController.navigate("premium") },
                onNavigateToCleaner = { cleanType ->
                  viewModel.setActiveCleanType(cleanType)
                  navController.navigate("cleaner")
                }
              )
            }
            composable("cleaner") {
              CleanerScreen(
                viewModel = viewModel,
                onNavigateBack = {
                  navController.popBackStack()
                }
              )
            }
            composable("battery") {
              BatteryInfoScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
              )
            }
            composable("premium") {
              PremiumScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
              )
            }
            composable("settings") {
              SettingsScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
              )
            }
            composable("apk_installer") {
              ApkInstallerScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
              )
            }
          }
        }
       }
      }
    }
  }
}

